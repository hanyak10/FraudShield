package com.fraudshield.service;

import com.fraudshield.model.FraudRule;
import com.fraudshield.model.Transaction;
import com.fraudshield.model.TransactionStatus;
import com.fraudshield.model.Verdict;
import com.fraudshield.repository.FraudRuleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

/**
 * Unit tests for the deterministic fraud-scoring engine. No Spring context is
 * loaded here — the repository is mocked so these tests also validate that
 * core business logic still behaves correctly after the Spring Boot 4.1 /
 * Java 21 upgrade.
 */
@ExtendWith(MockitoExtension.class)
class RulesEngineServiceTest {

    @Mock
    private FraudRuleRepository fraudRuleRepository;

    private RulesEngineService rulesEngineService;

    @BeforeEach
    void setUp() {
        rulesEngineService = new RulesEngineService(fraudRuleRepository);
    }

    private FraudRule rule(String id, String name, int weight, boolean enabled) {
        return new FraudRule(id, name, "desc", weight, enabled);
    }

    private Transaction txWithAmount(BigDecimal amount) {
        Transaction tx = new Transaction();
        tx.setId("tx-99001");
        tx.setMerchantId("MERCH-TEST-01");
        tx.setAmount(amount);
        tx.setCreatedAt(Instant.parse("2026-01-01T12:00:00Z")); // daytime, avoids nightowl
        return tx;
    }

    @Test
    void amountRuleFires_whenAmountExceedsThreshold_andScoreIsFlagged() {
        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(
                rule("amount", "Amount Anomaly", 30, true)
        ));

        RulesEngineService.ScoreResult result = rulesEngineService.score(txWithAmount(new BigDecimal("2500.00")));

        assertThat(result.score()).isEqualTo(30);
        assertThat(result.firedRuleIds()).containsExactly("amount");
        // 30 < 50, so PASSED even though the rule fired.
        assertThat(result.verdict()).isEqualTo(Verdict.PASSED);
        assertThat(result.status()).isEqualTo(TransactionStatus.PASSED);
    }

    @Test
    void amountRuleDoesNotFire_whenAmountAtOrBelowThreshold() {
        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(
                rule("amount", "Amount Anomaly", 30, true)
        ));

        RulesEngineService.ScoreResult result = rulesEngineService.score(txWithAmount(new BigDecimal("2000.00")));

        assertThat(result.score()).isZero();
        assertThat(result.firedRuleIds()).isEmpty();
        assertThat(result.verdict()).isEqualTo(Verdict.PASSED);
    }

    @Test
    void transactionIsFlagged_whenCombinedScoreReachesFiftyThreshold() {
        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(
                rule("amount", "Amount Anomaly", 30, true),
                rule("nightowl", "Odd-Hour Spending", 20, true)
        ));

        Transaction tx = new Transaction();
        tx.setId("tx-99002");
        tx.setMerchantId("MERCH-TEST-02");
        tx.setAmount(new BigDecimal("5000.00"));
        // 03:00 UTC falls in the nightowl window [2,5) and amount > 1000.
        ZonedDateTime nightOwlTime = ZonedDateTime.of(2026, 1, 1, 3, 0, 0, 0, ZoneOffset.UTC);
        tx.setCreatedAt(nightOwlTime.toInstant());

        RulesEngineService.ScoreResult result = rulesEngineService.score(tx);

        assertThat(result.score()).isEqualTo(50);
        assertThat(result.firedRuleIds()).containsExactlyInAnyOrder("amount", "nightowl");
        assertThat(result.verdict()).isEqualTo(Verdict.FLAGGED);
        assertThat(result.status()).isEqualTo(TransactionStatus.PENDING);
    }

    @Test
    void disabledRulesAreNeverLoaded_becauseRepositoryOnlyReturnsEnabledRules() {
        // findByEnabledTrue() is the only query the engine issues, so a disabled
        // rule (e.g. nightowl, seeded disabled) never reaches fires() at all.
        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of());

        RulesEngineService.ScoreResult result = rulesEngineService.score(txWithAmount(new BigDecimal("999999.00")));

        assertThat(result.score()).isZero();
        assertThat(result.verdict()).isEqualTo(Verdict.PASSED);
    }

    @Test
    void unknownRuleId_neverFires() {
        when(fraudRuleRepository.findByEnabledTrue()).thenReturn(List.of(
                rule("made-up-rule", "Not A Real Rule", 100, true)
        ));

        RulesEngineService.ScoreResult result = rulesEngineService.score(txWithAmount(new BigDecimal("10.00")));

        assertThat(result.score()).isZero();
        assertThat(result.firedRuleIds()).isEmpty();
    }
}
