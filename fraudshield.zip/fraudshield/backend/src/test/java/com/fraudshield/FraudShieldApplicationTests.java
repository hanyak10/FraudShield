package com.fraudshield;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

/**
 * Full application-context smoke test for the Spring Boot 4.1 / Java 21
 * upgrade. Loads every bean (security filter chain, JPA repositories, JWT
 * services, Eureka client auto-configuration, etc.) and fails fast if any
 * wiring broke during the migration. Eureka registration is disabled so the
 * test never depends on a live registry being reachable.
 */
@SpringBootTest
@TestPropertySource(properties = {
        "eureka.client.enabled=false",
        "spring.cloud.discovery.enabled=false"
})
class FraudShieldApplicationTests {

    @Test
    void applicationContextLoads() {
        // Intentionally empty: success means every bean in the context
        // (controllers, services, repositories, SecurityFilterChain,
        // JwtAuthenticationFilter, DataInitializer, etc.) was created
        // without error on Spring Boot 4.1.2 / Java 21.
    }
}
